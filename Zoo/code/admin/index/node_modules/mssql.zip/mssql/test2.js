'use strict'

const sql = require('./')
const { resolve } = require('./lib/connectionstring');
// const wtf = require('wtfnode')

const sqlConfig = {
  password: 'Upper_l0wercase',
  database: 'di_production',
  // connectionTimeout: undefined,
  // requestTimeout: 30000,
  stream: false,
  options: { encrypt: true },
  port: 1433,
  user: 'sa',
  server: 'localhost',
  pool: {
    acquireTimeoutMillis: 1000,
    propagateCreateError: true
  }
}

const sqlConfigStr = 'Server=localhost,1433;Database=di_production;User Id=sa;Password=Upper_l0wercase;Encrypt=true;ApplicationIntent=ReadOnly'

console.log(resolve(sqlConfigStr));

let count = 0

function badUUIDReq (pool) {
  const req = pool.request()
  req.input('id', sql.UniqueIdentifier, 'foobar')
  return req.query("select * from TestUniqueId where id = @id").catch((e) => {
    console.log('Request threw exception', e)
    // if (count++ < 15) {
    //   return badUUIDReq(pool)
    // } else {
      throw e
    // }
  })
}

function main () {
  sql.connect(sqlConfig).then((connection) => {
    return badUUIDReq(connection)
  }).then((result) => {
    console.dir(result)
  }).then(() => sql.close()).catch(() => {
    return sql.close()
  })
}

// main()
const pool2 = new sql.ConnectionPool(sqlConfig).connect().catch(e => {
  console.error('catch e', e)
});

pool2.then((pool) => {
  pool.on('error', err => {
    console.error('error: ', err)
  })
  return pool
})

pool2.then((p) => badUUIDReq(p).catch(() => p.close()))
